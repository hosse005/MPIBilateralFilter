## Instruction for compiling and running Evan Hosseini's Project 2 on Peregrine Cluster

1. Move the compressed tarball to the cluster and unpack
2. Execute the following command to compile:
	sbatch mpi-build.sbatch
3. Make sure that the florida_satellite_filtered.pgm file has sufficient write 
   permissions
4. Edit the mpi-run.sbatch file to change runtime parameters
   (e.g line 2 for changing number of processors, and line 31, last argument to change 
    the corresponding sub-division parameter)
5. Execute the following command to run:
	sbatch mpi-run.sbatch
6. I have included all slurm output files from the three runs I did on the cluster in the 
   package along with the input and output filtered image.
