
PATH=${PATH}:/usr/local/mpi/openmpi/bin
export PATH

